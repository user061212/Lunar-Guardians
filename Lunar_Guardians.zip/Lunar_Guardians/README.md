# Lunar Guardians (v3)
Picture-first Moon game for ages 6-12. Keep Mira and Leo safe for 5 Moon days.
Run: open `index.html` (or use VS Code Live Server). No install needed.

## How to play
1. **Sign up / Log in** with a nickname, a buddy picture and a 4-number secret PIN. Progress is saved for each player.
2. **Day 1 is a guided tutorial** (new players only): a practice flare drill, then every action is shown step by step with a glowing button. From Day 2 on there are **no hints**.
3. **Sunshine** ☀️: tap falling ✨ for 7 seconds. Catch **4 or more** or the try fails and you lose a ❤️. You have **3 hearts** for the whole mission. Lose all 3 and Mira and Leo fly back to Earth. After a good catch, spell the bonus power word for extra ⭐ and +1 🔋.
4. **Food / Water / Air**: spell the word from the picture to make supplies. Days 1-2: pick the missing letter. Days 3-5: unscramble the letters. Wrong letters never cost anything. Each word has a fun space/science fact.
5. Hide the crew on big-flare days (real NASA data), then Sleep.
6. **My Space Log** shows missions, best stars, rank, words learned and recent missions.

## Easy settings (top of `script.js`)
- `LIVES` = hearts per mission (default 3)
- `CATCH_NEED` = sunshine needed per try (default 4)
- `WORDS` = add your own words: `["WORD", "emoji", "fun fact"]`

## Privacy
Accounts live **only in this browser** (`localStorage`). Nothing is sent to any server. We store a nickname, a buddy emoji, a salted hash of the PIN, and game progress. The PIN is a simple lock to keep siblings out of each other's progress, not strong security, so the sign-up page tells children to use a nickname and not their real name. Progress is per device/browser: a different computer starts fresh. Sound/voice can be muted with the speaker button.
Data: see DATA_SOURCES.md.
