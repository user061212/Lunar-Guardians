# DATA_SOURCES

| Item | Source | How it is used | Status |
|---|---|---|---|
| Solar flares (FLR) | NASA DONKI via https://api.nasa.gov (endpoint `/DONKI/FLR`) | Each Moon day's "Sun Watch" shows a real flare record (class + date). M and X class flares start the shelter drill. | LIVE when the API answers; the game shows "LIVE NASA data" |
| Archived fallback | DONKI / NASA space weather news (May 2024 and Oct 2024 X-class flares) | Used only if the API fails or is rate-limited. The game shows "ARCHIVED NASA data". | **TEAM MUST VERIFY dates and classes on https://kauai.ccmc.gsfc.nasa.gov/DONKI/ before submitting** |
| Game numbers (supplies, costs) | Invented for gameplay | Simplified simulation. Not real NASA measurements or radiation doses. | Simulated |
| Word challenge facts | Written by the team for the game (e.g. lettuce and tomatoes grown on the Space Station, ice at the Moon's poles, Moon night lasts about 14 Earth days) | Short fun facts shown after a word is spelled | **TEAM SHOULD double-check each fact in `WORDS` in script.js against NASA pages before submitting** |
| Player accounts and progress | Created by the player in this browser (`localStorage`) | Nickname, buddy emoji, hashed PIN, scores, words learned. Never leaves the device | No server, no tracking |
| Emoji art | System emoji | Pictures | No external assets |

## Before you submit
1. Get a personal API key at https://api.nasa.gov and put it in `script.js` (`NASA_KEY`). `DEMO_KEY` is rate-limited and may fail in a judging room.
2. Open the game online once and confirm the badge says "LIVE NASA data".
3. Verify the archived records above.
4. Check the hackathon rules on AI-assistance disclosure.
