// LUNAR GUARDIANS v2 – a picture-first Moon game for ages 6-12.
// Real NASA data: DONKI solar flares (FLR). If NASA is unreachable, bundled ARCHIVED data is used and labelled.
const NASA_KEY = "DEMO_KEY"; // TODO: replace with your own free key from https://api.nasa.gov (DEMO_KEY is rate-limited)
const MAX = 8, DAYS = 5;
const $ = id => document.getElementById(id);
const SUP = { energy: "🔋", water: "💧", air: "🫧", food: "🥕" };
const STICKERS = ["🌟", "🚀", "🪐", "🛰️", "🏆"];
// ARCHIVED fallback. Team: verify these on https://kauai.ccmc.gsfc.nasa.gov/DONKI/ before submitting (see DATA_SOURCES.md)
const ARCHIVE = [
  { c: "", t: "" },
  { c: "X5.8", t: "2024-05-11" },
  { c: "", t: "" },
  { c: "X9.0", t: "2024-10-03" },
  { c: "", t: "" }
];
let sun = { live: false, days: ARCHIVE }, ready = null;
let s, day, stars, storm, sheltered, did, perfect, got, sounds = true, lastDay;

// ---------- sound + voice ----------
function beep(f = 520, t = .12, type = "sine") { if (!sounds) return; try { const c = beep.c || (beep.c = new (window.AudioContext || window.webkitAudioContext)()), o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.value = .06; o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + t); } catch (e) {} }
function speak(t) { if (!sounds || !window.speechSynthesis) return; try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(t.replace(/[^\w\s.,!?']/g, " ")); u.rate = .9; u.pitch = 1.2; speechSynthesis.speak(u); } catch (e) {} }
function say(face, text) { $("face").textContent = face; $("msg").textContent = text; speak(text); }
function toggleSound() { sounds = !sounds; $("voice").textContent = $("voiceT").textContent = sounds ? "🔊" : "🔇"; if (!sounds && window.speechSynthesis) speechSynthesis.cancel(); beep(); }

// ---------- NASA DONKI ----------
const strength = c => ({ X: 3, M: 2 }[(c || "")[0]] || 1);
async function loadNasa() {
  const f = d => d.toISOString().slice(0, 10), e = new Date(), b = new Date(e - 30 * 864e5), ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 6000);
  try {
    const r = await fetch(`https://api.nasa.gov/DONKI/FLR?startDate=${f(b)}&endDate=${f(e)}&api_key=${NASA_KEY}`, { signal: ctl.signal });
    if (!r.ok) throw new Error(r.status);
    const j = await r.json(); if (!Array.isArray(j) || !j.length) throw new Error("empty");
    const recs = j.map(x => ({ c: x.classType || "", t: (x.peakTime || x.beginTime || "").slice(0, 10), l: x.link || "" })).sort((p, q) => strength(q.c) - strength(p.c));
    const calm = recs.slice(2).reverse(); // weaker flares become calm days
    const pickCalm = i => calm[i % Math.max(1, calm.length)] || { c: "", t: "" };
    sun = { live: true, days: [pickCalm(0), recs[0], pickCalm(1), recs[1] || recs[0], pickCalm(2)] };
  } catch (err) { sun = { live: false, days: ARCHIVE }; }
  clearTimeout(to);
}
function kidFlare(c) { return { 3: "a HUGE flare!", 2: "a medium flare!" }[strength(c)] || "a tiny flare"; }
async function sunWatch() {
  $("sun").classList.add("on"); $("sunOk").disabled = true; $("sunLink").hidden = true;
  $("badge").textContent = "Contacting NASA…"; $("badge").className = "badge"; $("sunTxt").textContent = "🛰️ …";
  await ready; const r = sun.days[day - 1] || { c: "", t: "" };
  storm = strength(r.c) >= 2 && !!r.c; sheltered = false;
  $("badge").textContent = sun.live ? "🟢 LIVE NASA data (DONKI)" : "🟡 ARCHIVED NASA data (DONKI)";
  $("badge").className = "badge " + (sun.live ? "live" : "arc");
  $("sunTxt").textContent = r.c ? `${storm ? "⚠️" : "🌤️"} NASA saw ${kidFlare(r.c)} (${r.c}) on ${r.t}. ${storm ? "Big flares send energy to space! Hide the crew!" : "Small flares are safe."}` : "🌤️ A calm Sun day. No big flares!";
  if (r.l) { $("sunLink").href = r.l; $("sunLink").hidden = false; }
  $("sunOk").disabled = false; document.body.classList.toggle("storm", storm);
  speak(storm ? "Oh no! A big sun flare! Tap Mira and Leo to hide!" : "The Sun is calm today!"); beep(storm ? 220 : 660, .25);
}

// ---------- game ----------
function newGame() {
  s = { energy: 5, water: 5, air: 5, food: 5 }; day = 1; stars = 0; got = []; perfect = 0; storm = sheltered = false; startDay(); show("game");
}
function show(id) { document.querySelectorAll(".screen").forEach(x => x.classList.toggle("on", x.id == id)); }
async function startDay() {
  did = { food: 0, water: 0, air: 0, sun: 0 }; lastDay = { care: false };
  ["mira", "leo"].forEach(k => $(k).classList.remove("in")); $("shield").classList.remove("on"); document.body.classList.remove("night");
  render(); await sunWatch(); render();
}
function render() {
  $("days").innerHTML = Array.from({ length: DAYS }, (_, i) => `<span class="${i + 1 < day ? "done" : i + 1 == day ? "on" : ""}">${i + 1 < day ? "🌕" : "🌑"}</span>`).join("");
  $("sc").textContent = stars;
  $("sup").innerHTML = Object.entries(s).map(([k, v]) => `<div class="sp ${v <= 2 ? "low" : ""}" aria-label="${k} ${v} of ${MAX}">${SUP[k]}<div class="pips">${Array.from({ length: MAX }, (_, i) => `<b class="${i < v ? "f" : ""}"></b>`).join("")}</div></div>`).join("");
  $("bSun").disabled = did.sun >= 2 || s.energy >= MAX;
  $("bFood").disabled = did.food || s.energy < 1 || s.water < 1 || s.food >= MAX;
  $("bWater").disabled = did.water || s.energy < 1 || s.water >= MAX;
  $("bAir").disabled = did.air || s.energy < 1 || s.air >= MAX;
  ["Food", "Water", "Air"].forEach(n => $("b" + n).classList.toggle("done", !!did[n.toLowerCase()]));
  document.querySelectorAll(".hint").forEach(x => x.classList.remove("hint"));
  const h = hint(); if (h) $(h).classList.add("hint");
}
function hint() {
  if (storm && !sheltered) return ["mira", "leo"].find(k => !$(k).classList.contains("in"));
  if (s.energy < 3 && did.sun < 2) return "bSun";
  const need = [["water", "bWater"], ["air", "bAir"], ["food", "bFood"]].filter(([k, b]) => !did[k] && !$(b).disabled).sort((a, b) => s[a[0]] - s[b[0]])[0];
  return need && s[need[0]] <= 5 ? need[1] : "bSleep";
}
function gain(k, n) { const g = Math.min(MAX, s[k] + n) - s[k]; s[k] += g; return g; }
function reward(n = 1) { stars += n; beep(780); beep(990, .1); }
function act(kind) {
  if (kind == "food") { s.energy--; s.water--; gain("food", 2); did.food = 1; say("🥕", "Yummy carrots!"); }
  if (kind == "water") { s.energy--; gain("water", 2); did.water = 1; say("💧", "Fresh water!"); }
  if (kind == "air") { s.energy--; gain("air", 2); did.air = 1; say("🫧", "Fresh air!"); }
  reward(); render();
}
function hide(k) {
  $(k).classList.add("in"); beep(400); const both = $("mira").classList.contains("in") && $("leo").classList.contains("in");
  if (!both) return say("🛡️", "One more astronaut!");
  sheltered = true; s.energy = Math.max(0, s.energy - 1); $("shield").classList.add("on"); reward(2); say("🎉", "Safe! Great job!"); render();
}
function catchGame() {
  did.sun++; let n = 0, t = 7; $("catch").classList.add("on"); $("cn").textContent = 0; $("tm").textContent = t; $("field").innerHTML = "";
  const sp = setInterval(() => { const b = document.createElement("button"); b.className = "spark"; b.textContent = Math.random() < .5 ? "✨" : "⭐"; b.style.left = Math.random() * 80 + "%"; b.setAttribute("aria-label", "sunshine");
    b.onpointerdown = () => { if (b.classList.contains("pop")) return; b.classList.add("pop"); n++; $("cn").textContent = n; beep(600 + n * 40, .08); }; $("field").appendChild(b); setTimeout(() => b.remove(), 2500); }, 420);
  const tm = setInterval(() => { $("tm").textContent = --t; if (t > 0) return; clearInterval(sp); clearInterval(tm);
    const g = gain("energy", Math.min(n, 6)); $("catch").classList.remove("on"); reward(Math.ceil(n / 3)); say("☀️", g ? `You got ${g} power!` : "Power is full!"); render(); }, 1000);
}
function sleep() {
  document.body.classList.add("night"); beep(300, .4); say("😴", "Sleepy time…");
  setTimeout(() => {
    let care = false; Object.keys(s).forEach(k => { s[k]--; if (s[k] <= 0) { s[k] = 2; care = true; } });
    if (storm && !sheltered) { s.energy = Math.max(0, s.energy - 2); say("😮", "Oops! The storm used power."); }
    if (care) say("📦", "Earth sent a care package!"); else perfect++, reward(3);
    got.push(STICKERS[day - 1]); beep(880, .3);
    storm = false; document.body.classList.remove("storm", "night");
    if (day >= DAYS) return end();
    day++; startDay();
  }, 1400);
}
function end() {
  show("end"); const r = perfect >= 5 ? 3 : perfect >= 3 ? 2 : 1;
  $("eTitle").textContent = r == 3 ? "Super Guardian!" : r == 2 ? "Moon Hero!" : "Space Explorer!";
  $("eEmoji").textContent = ["🌙", "🚀", "🏆"][r - 1]; $("eStars").textContent = "⭐".repeat(r) + ` · ${stars} stars`;
  $("stick").textContent = got.join(" "); $("eTxt").textContent = "You kept Mira and Leo safe for 5 Moon days!";
  speak("Hooray! You kept Mira and Leo safe!");
  for (let i = 0; i < 40; i++) { const c = document.createElement("span"); c.className = "conf"; c.textContent = pick(["🎉", "⭐", "✨", "🌟"]); c.style.left = Math.random() * 100 + "%"; c.style.animationDelay = Math.random() * 2 + "s"; document.body.appendChild(c); setTimeout(() => c.remove(), 5500); }
}
const pick = a => a[Math.floor(Math.random() * a.length)];

// ---------- wiring ----------
for (let i = 0; i < 70; i++) { const d = document.createElement("i"); d.style.left = Math.random() * 100 + "%"; d.style.top = Math.random() * 100 + "%"; d.style.animationDelay = Math.random() * 3 + "s"; $("sky").appendChild(d); }
$("play").onclick = () => { beep(660); ready = ready || loadNasa(); newGame(); };
ready = loadNasa(); // start fetching right away
$("voice").onclick = $("voiceT").onclick = toggleSound;
$("sunOk").onclick = () => { $("sun").classList.remove("on"); beep(); say(storm ? "🚨" : "🤖", storm ? "Tap Mira and Leo!" : day == 1 ? "Tap the glowing button!" : "What do we need?"); render(); };
$("bSun").onclick = catchGame; $("bFood").onclick = () => act("food"); $("bWater").onclick = () => act("water"); $("bAir").onclick = () => act("air");
$("bSleep").onclick = sleep; $("mira").onclick = () => hide("mira"); $("leo").onclick = () => hide("leo");
$("again").onclick = () => { ready = loadNasa(); newGame(); };
