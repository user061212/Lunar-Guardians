# Lunar Guardians (v2)
Picture-first Moon game for ages 6-12. Keep Mira and Leo safe for 5 Moon days.
Run: open `index.html` (or use VS Code Live Server). No install needed.
Play: tap the glowing button, catch sunshine, make food/water/air, hide the crew during real-NASA-data flare days, then sleep.
Privacy: no accounts, no tracking, no personal data. Sound/voice can be muted with the speaker button.
Data: see DATA_SOURCES.md.
