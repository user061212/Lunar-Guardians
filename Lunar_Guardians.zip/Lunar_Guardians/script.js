// LUNAR GUARDIANS v3 – a picture-first Moon game for ages 6-12.
// Real NASA data: DONKI solar flares (FLR). If NASA is unreachable, bundled ARCHIVED data is used and labelled.
// v3 adds: local login/sign-up + saved progress, a tutorial day, 3 lives in the sunshine game, and word challenges.
const NASA_KEY = "DEMO_KEY"; // TODO: replace with your own free key from https://api.nasa.gov (DEMO_KEY is rate-limited)
const MAX = 8, DAYS = 5;
const LIVES = 3;        // hearts for the whole mission (lost on a failed sunshine try)
const CATCH_NEED = 4;   // sunshine to catch in one try, or the try fails
const $ = id => document.getElementById(id);
const SUP = { energy: "🔋", water: "💧", air: "🫧", food: "🥕" };
const STICKERS = ["🌟", "🚀", "🪐", "🛰️", "🏆"];
const RANKS = ["Space Explorer", "Moon Hero", "Super Guardian"];
// ARCHIVED fallback. Team: verify these on https://kauai.ccmc.gsfc.nasa.gov/DONKI/ before submitting (see DATA_SOURCES.md)
const ARCHIVE = [
  { c: "", t: "" },
  { c: "X5.8", t: "2024-05-11" },
  { c: "", t: "" },
  { c: "X9.0", t: "2024-10-03" },
  { c: "", t: "" }
];
let sun = { live: false, days: ARCHIVE }, ready = null;
let s, day, stars, storm, sheltered, did, perfect, got, sounds = true, lastDay;
let lives, tut, grad, locked, gameWords, wordKey = null;
const used = new Set();
const pick = a => a[Math.floor(Math.random() * a.length)];
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const esc = t => String(t).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ---------- sound + voice ----------
function beep(f = 520, t = .12, type = "sine") { if (!sounds) return; try { const c = beep.c || (beep.c = new (window.AudioContext || window.webkitAudioContext)()), o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.value = .06; o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + t); } catch (e) {} }
function speak(t) { if (!sounds || !window.speechSynthesis) return; try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(t.replace(/[^\w\s.,!?']/g, " ")); u.rate = .9; u.pitch = 1.2; speechSynthesis.speak(u); } catch (e) {} }
function say(face, text) { $("face").textContent = face; $("msg").textContent = text; speak(text); }
function toggleSound() { sounds = !sounds; $("voice").textContent = $("voiceT").textContent = sounds ? "🔊" : "🔇"; if (!sounds && window.speechSynthesis) speechSynthesis.cancel(); beep(); }

// ---------- accounts (stored ONLY in this browser; nickname + 4-digit PIN, no real data) ----------
// The PIN is a simple lock to keep siblings out of each other's progress. It is NOT strong security.
const DB_KEY = "lunarGuardians.players.v1", SESSION_KEY = "lunarGuardians.session";
const AVATARS = ["🐱", "🐶", "🦊", "🐼", "🐸", "🦄", "🐙", "🦖"];
const NAME_RE = /^[\p{L}\p{N} _-]{2,12}$/u;
let memDB = {}, storageOk = true, me = null, pickedAvatar = AVATARS[0];
try { localStorage.setItem("lg.t", "1"); localStorage.removeItem("lg.t"); } catch (e) { storageOk = false; }
const loadDB = () => { if (!storageOk) return memDB; try { return JSON.parse(localStorage.getItem(DB_KEY)) || {}; } catch (e) { return {}; } };
const saveDB = db => { memDB = db; if (!storageOk) return; try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch (e) { storageOk = false; } };
const keyOf = n => n.trim().toLowerCase();
const player = () => me ? loadDB()[me] : null;
function updatePlayer(fn) { const db = loadDB(); if (!me || !db[me]) return; fn(db[me]); saveDB(db); }
function hashPin(salt, pin) { // cyrb53 – small, dependency-free hash (works on file:// and http://)
  const str = salt + ":" + pin; let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
function signIn(k) { me = k; try { sessionStorage.setItem(SESSION_KEY, k); } catch (e) {} refreshTitle(); show("title"); beep(700); }
function signOut() { me = null; try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {} refreshTitle(); show("title"); }
function refreshTitle() {
  const p = player();
  $("who").hidden = $("logBtn").hidden = $("outBtn").hidden = !p;
  if (p) $("who").textContent = `${p.avatar} Welcome, ${p.name}!`;
}
function setTab(t) {
  $("tabLogin").classList.toggle("on", t == "login"); $("tabSign").classList.toggle("on", t == "sign");
  $("fLogin").hidden = t != "login"; $("fSign").hidden = t != "sign"; $("aErr").textContent = "";
}
function renderChips() {
  const all = Object.values(loadDB());
  $("chips").innerHTML = all.map(p => `<button type="button" class="chip" data-n="${esc(p.name)}">${esc(p.avatar)} ${esc(p.name)}</button>`).join("");
  $("chips").hidden = !all.length;
}
function renderAvatars() {
  $("avatars").innerHTML = AVATARS.map(a => `<button type="button" class="av ${a == pickedAvatar ? "on" : ""}" role="radio" aria-checked="${a == pickedAvatar}" data-a="${a}">${a}</button>`).join("");
}
function openAuth(tab) {
  setTab(tab || (Object.keys(loadDB()).length ? "login" : "sign"));
  renderChips(); renderAvatars(); $("storeWarn").hidden = storageOk;
  ["liName", "liPin", "suName", "suPin", "suPin2"].forEach(i => $(i).value = "");
  show("auth");
}
function doSignUp(e) {
  e.preventDefault();
  const name = $("suName").value.trim().replace(/\s+/g, " "), pin = $("suPin").value, pin2 = $("suPin2").value, db = loadDB();
  const err = !NAME_RE.test(name) ? "Your nickname needs 2 to 12 letters or numbers."
    : !/^\d{4}$/.test(pin) ? "Your secret PIN needs exactly 4 numbers."
    : pin !== pin2 ? "The two PINs are different. Try again!"
    : db[keyOf(name)] ? "Someone already has that nickname. Try another one!" : "";
  if (err) { $("aErr").textContent = err; beep(200, .2, "square"); return; }
  const salt = Math.random().toString(36).slice(2, 10);
  db[keyOf(name)] = { name, avatar: pickedAvatar, salt, h: hashPin(salt, pin), created: Date.now(), tutorialDone: false, games: 0, wins: 0, bestStars: 0, bestRank: 0, totalStars: 0, words: [], history: [] };
  saveDB(db); signIn(keyOf(name));
}
function doLogIn(e) {
  e.preventDefault();
  const name = $("liName").value.trim(), pin = $("liPin").value, p = loadDB()[keyOf(name)];
  if (!p || p.h !== hashPin(p.salt, pin)) { $("aErr").textContent = "Hmm, that nickname and PIN don't match. Try again!"; $("liPin").value = ""; beep(200, .2, "square"); return; }
  signIn(keyOf(name));
}
function openLog() {
  const p = player(); if (!p) return openAuth();
  const total = Object.values(WORDS).reduce((n, a) => n + a.length, 0);
  $("lWho").textContent = `${p.avatar} ${p.name}`;
  $("lStats").innerHTML = [["🎮", "Missions", p.games], ["🏆", "Completed", p.wins], ["⭐", "Best stars", p.bestStars], ["🌟", "Total stars", p.totalStars], ["🎖️", "Best rank", p.bestRank ? RANKS[p.bestRank - 1] : "–"], ["🔤", "Words", `${p.words.length}/${total}`]]
    .map(([i, l, v]) => `<div class="stat"><i>${i}</i><b>${esc(v)}</b><small>${l}</small></div>`).join("");
  $("lWords").innerHTML = p.words.length ? p.words.map(w => `<span class="chip">${esc(w)}</span>`).join("") : `<span class="tiny">Spell words in the game to collect them here!</span>`;
  $("lHist").innerHTML = p.history.length ? p.history.map(h => `<li>${h.done ? "✅ " + RANKS[h.rank - 1] : "🚀 Flew home on Day " + h.day} · ⭐ ${h.stars} · ${new Date(h.d).toLocaleDateString()}</li>`).join("") : `<li>No missions yet. Press PLAY!</li>`;
  show("log");
}
function record(done, rank) {
  updatePlayer(p => {
    p.games++; if (done) { p.wins++; p.bestRank = Math.max(p.bestRank, rank); }
    p.totalStars += stars; p.bestStars = Math.max(p.bestStars, stars);
    p.history.unshift({ d: Date.now(), done, rank: done ? rank : 0, stars, day });
    p.history = p.history.slice(0, 8);
  });
}
function learned(word) { gameWords.add(word); updatePlayer(p => { if (!p.words.includes(word)) p.words.push(word); }); }

// ---------- NASA DONKI ----------
const strength = c => ({ X: 3, M: 2 }[(c || "")[0]] || 1);
async function loadNasa() {
  const f = d => d.toISOString().slice(0, 10), e = new Date(), b = new Date(e - 30 * 864e5), ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 6000);
  try {
    const r = await fetch(`https://api.nasa.gov/DONKI/FLR?startDate=${f(b)}&endDate=${f(e)}&api_key=${NASA_KEY}`, { signal: ctl.signal });
    if (!r.ok) throw new Error(r.status);
    const j = await r.json(); if (!Array.isArray(j) || !j.length) throw new Error("empty");
    const recs = j.map(x => ({ c: x.classType || "", t: (x.peakTime || x.beginTime || "").slice(0, 10), l: x.link || "" })).sort((p, q) => strength(q.c) - strength(p.c));
    const calm = recs.slice(2).reverse(); // weaker flares become calm days
    const pickCalm = i => calm[i % Math.max(1, calm.length)] || { c: "", t: "" };
    sun = { live: true, days: [pickCalm(0), recs[0], pickCalm(1), recs[1] || recs[0], pickCalm(2)] };
  } catch (err) { sun = { live: false, days: ARCHIVE }; }
  clearTimeout(to);
}
function kidFlare(c) { return { 3: "a HUGE flare!", 2: "a medium flare!" }[strength(c)] || "a tiny flare"; }
async function sunWatch() {
  $("sun").classList.add("on"); $("sunOk").disabled = true; $("sunLink").hidden = true;
  $("badge").textContent = "Contacting NASA…"; $("badge").className = "badge"; $("sunTxt").textContent = "🛰️ …";
  await ready;
  if (tut) { // Tutorial day: a clearly-labelled PRACTICE flare so every child learns the shelter drill
    storm = true; sheltered = false;
    $("badge").textContent = "🎓 Practice day (not real data)"; $("badge").className = "badge tut";
    $("sunTxt").textContent = "⚠️ Practice flare! Big flares send energy to space. Tap Mira and Leo to hide them!";
    $("sunOk").disabled = false; document.body.classList.add("storm");
    speak("Practice day! A big sun flare is coming. Tap Mira and Leo to hide!"); beep(220, .25); return;
  }
  const r = sun.days[day - 1] || { c: "", t: "" };
  storm = strength(r.c) >= 2 && !!r.c; sheltered = false;
  $("badge").textContent = sun.live ? "🟢 LIVE NASA data (DONKI)" : "🟡 ARCHIVED NASA data (DONKI)";
  $("badge").className = "badge " + (sun.live ? "live" : "arc");
  // No "what to do" instructions outside the tutorial: the child decides.
  $("sunTxt").textContent = r.c ? `${storm ? "⚠️" : "🌤️"} NASA saw ${kidFlare(r.c)} (${r.c}) on ${r.t}. ${storm ? "Big flares send energy to space!" : "Small flares are safe."}` : "🌤️ A calm Sun day. No big flares!";
  if (r.l) { $("sunLink").href = r.l; $("sunLink").hidden = false; }
  $("sunOk").disabled = false; document.body.classList.toggle("storm", storm);
  speak(storm ? "Oh no! A big sun flare!" : "The Sun is calm today!"); beep(storm ? 220 : 660, .25);
}

// ---------- tutorial (day 1 for new players only) ----------
function tutStep() {
  if (storm && !sheltered) return { t: ["mira", "leo"].find(k => !$(k).classList.contains("in")), f: "🛡️", m: "A flare is coming! Tap Mira and Leo to hide them under the shield." };
  if (!did.sunOk) return { t: "bSun", f: "☀️", m: `Power comes from the Sun. Tap Sunshine and catch ${CATCH_NEED} or more ✨! (Practice is free: no hearts lost.)` };
  if (!did.water) return { t: "bWater", f: "💧", m: "Now make water. Tap Water and spell the word. It uses 1 🔋." };
  if (!did.air) return { t: "bAir", f: "🫧", m: "Next, fresh air! Tap Air. It also uses 1 🔋." };
  if (!did.food) return { t: "bFood", f: "🥕", m: "Now food! It uses 1 🔋 and 1 💧." };
  return { t: "bSleep", f: "🌙", m: "All done! Tap Sleep to end the day. Supplies go down a little every night." };
}
function tutSay(prefix = "") { if (!tut) return; const x = tutStep(); say(x.f, prefix + x.m); }

// ---------- game ----------
function newGame() {
  const p = player(); tut = !(p && p.tutorialDone); grad = false; locked = false;
  s = { energy: 5, water: 5, air: 5, food: 5 }; day = 1; stars = 0; got = []; perfect = 0; storm = sheltered = false; lives = LIVES;
  gameWords = new Set(); used.clear(); startDay(); show("game");
}
function show(id) { document.querySelectorAll(".screen").forEach(x => x.classList.toggle("on", x.id == id)); }
async function startDay() {
  locked = false; did = { food: 0, water: 0, air: 0, sun: 0, sunOk: 0 }; lastDay = { care: false };
  ["mira", "leo"].forEach(k => $(k).classList.remove("in")); $("shield").classList.remove("on"); document.body.classList.remove("night");
  render(); await sunWatch(); render();
}
const hearts = () => Array.from({ length: LIVES }, (_, i) => i < lives ? "❤️" : "🖤").join("");
function render() {
  $("days").innerHTML = Array.from({ length: DAYS }, (_, i) => `<span class="${i + 1 < day ? "done" : i + 1 == day ? "on" : ""}">${i + 1 < day ? "🌕" : "🌑"}</span>`).join("");
  $("sc").textContent = stars;
  $("lives").textContent = hearts(); $("lives").setAttribute("aria-label", `${lives} of ${LIVES} lives`);
  $("sup").innerHTML = Object.entries(s).map(([k, v]) => `<div class="sp ${v <= 2 ? "low" : ""}" aria-label="${k} ${v} of ${MAX}">${SUP[k]}<div class="pips">${Array.from({ length: MAX }, (_, i) => `<b class="${i < v ? "f" : ""}"></b>`).join("")}</div></div>`).join("");
  $("bSun").disabled = did.sun >= 2 || s.energy >= MAX;
  $("bFood").disabled = did.food || s.energy < 1 || s.water < 1 || s.food >= MAX;
  $("bWater").disabled = did.water || s.energy < 1 || s.water >= MAX;
  $("bAir").disabled = did.air || s.energy < 1 || s.air >= MAX;
  $("bSleep").disabled = false;
  ["Food", "Water", "Air"].forEach(n => $("b" + n).classList.toggle("done", !!did[n.toLowerCase()]));
  document.querySelectorAll(".hint").forEach(x => x.classList.remove("hint"));
  if (tut) { // Guided: only the next step is available and glowing. After the tutorial there are NO hints.
    const st = tutStep();
    ["bSun", "bFood", "bWater", "bAir", "bSleep"].forEach(b => { if (b != st.t) $(b).disabled = true; });
    $(st.t).classList.add("hint");
  }
}
function gain(k, n) { const g = Math.min(MAX, s[k] + n) - s[k]; s[k] += g; return g; }
function reward(n = 1) { stars += n; beep(780); beep(990, .1); }

async function act(kind) {
  if (locked) return;
  const r = await wordChallenge(kind);
  if (!r.ok) return render();
  if (kind == "food") { s.energy--; s.water--; gain("food", 2); did.food = 1; }
  if (kind == "water") { s.energy--; gain("water", 2); did.water = 1; }
  if (kind == "air") { s.energy--; gain("air", 2); did.air = 1; }
  learned(r.word); reward(r.perfect ? 2 : 1); render();
  say({ food: "🥕", water: "💧", air: "🫧" }[kind], r.perfect ? `${r.word}! First try! ${r.fact}` : `${r.word}! ${r.fact}`);
  if (tut) setTimeout(() => tutSay(), 200);
}
function hide(k) {
  if (locked) return;
  if (!storm) return say("😊", "No flare today. Mira and Leo are safe!");
  if (sheltered || $(k).classList.contains("in")) return;
  $(k).classList.add("in"); beep(400); const both = $("mira").classList.contains("in") && $("leo").classList.contains("in");
  if (!both) { render(); return say("🛡️", "One more astronaut!"); }
  sheltered = true; s.energy = Math.max(0, s.energy - 1); $("shield").classList.add("on"); reward(2); render();
  if (tut) tutSay("Safe! Great job! "); else say("🎉", "Safe! Great job!");
}

// ---------- sunshine game (3 hearts) ----------
function catchGame() {
  if (locked) return;
  did.sun++; let n = 0, t = 7; $("catch").classList.add("on"); $("cn").textContent = 0; $("tm").textContent = t; $("field").innerHTML = "";
  $("need").textContent = `Catch ${CATCH_NEED} or more ✨ to make power!` + (tut ? " (Practice: no hearts lost)" : ""); $("cLives").textContent = hearts();
  const sp = setInterval(() => { const b = document.createElement("button"); b.className = "spark"; b.textContent = Math.random() < .5 ? "✨" : "⭐"; b.style.left = Math.random() * 80 + "%"; b.setAttribute("aria-label", "sunshine");
    b.onpointerdown = () => { if (b.classList.contains("pop")) return; b.classList.add("pop"); n++; $("cn").textContent = n; beep(600 + n * 40, .08); }; $("field").appendChild(b); setTimeout(() => b.remove(), 2500); }, 420);
  const tm = setInterval(() => { $("tm").textContent = --t; if (t > 0) return; clearInterval(sp); clearInterval(tm); finishCatch(n); }, 1000);
}
async function finishCatch(n) {
  $("catch").classList.remove("on");
  if (n >= CATCH_NEED) {
    did.sunOk = 1; const g = gain("energy", Math.min(n, 6)); reward(Math.ceil(n / 3));
    say("☀️", g ? `You got ${g} power!` : "Power is full!"); render();
    { // optional bonus: Energy word challenge (bonus stars, plus +1 power if there is room)
      const r = await wordChallenge("energy");
      if (r.ok) { const b = gain("energy", 1); learned(r.word); reward(r.perfect ? 2 : 1); say("⚡", `${b ? "Bonus power! " : ""}${r.word}! ${r.fact}`); render(); }
    }
    if (tut) tutSay();
    return;
  }
  if (tut) { did.sun--; say("🤗", `Only ${n} ✨. Catch ${CATCH_NEED} or more! Practice is free, try again!`); return render(); }
  lives--; beep(180, .4, "sawtooth"); render();
  if (lives <= 0) { locked = true; say("😢", "No more hearts! Mira and Leo ran out of power and must fly back to Earth."); return void setTimeout(gameOver, 3200); }
  say("💔", `Only ${n} ✨. You lost a heart! ${lives} ${lives == 1 ? "heart" : "hearts"} left.`);
}

function sleep() {
  if (locked) return; locked = true;
  document.body.classList.add("night"); beep(300, .4); say("😴", "Sleepy time…");
  setTimeout(() => {
    let care = false; Object.keys(s).forEach(k => { s[k]--; if (s[k] <= 0) { s[k] = 2; care = true; } });
    if (storm && !sheltered) { s.energy = Math.max(0, s.energy - 2); say("😮", "Oops! The storm used power."); }
    if (care) say("📦", "Earth sent a care package!"); else perfect++, reward(3);
    got.push(STICKERS[day - 1]); beep(880, .3);
    if (tut) { tut = false; grad = true; updatePlayer(p => p.tutorialDone = true); }
    storm = false; document.body.classList.remove("storm", "night");
    if (day >= DAYS) return end();
    day++; startDay();
  }, 1400);
}
function sunOkClick() {
  $("sun").classList.remove("on"); beep();
  if (tut) return tutSay();
  if (grad) { grad = false; return say("🎓", "Practice is over! From now on, you're the Guardian. Good luck!"); }
  say(storm ? "🚨" : "🤖", storm ? "Flare alert!" : "What do we need?");
}

// ---------- end screens ----------
function end() {
  locked = true; show("end"); const r = perfect >= 5 ? 3 : perfect >= 3 ? 2 : 1;
  $("eTitle").textContent = r == 3 ? "Super Guardian!" : r == 2 ? "Moon Hero!" : "Space Explorer!";
  $("eEmoji").textContent = ["🌙", "🚀", "🏆"][r - 1]; $("eStars").textContent = "⭐".repeat(r) + ` · ${stars} stars`;
  $("stick").textContent = got.join(" "); $("eTxt").textContent = `You kept Mira and Leo safe for 5 Moon days!${gameWords.size ? ` You spelled ${gameWords.size} word${gameWords.size == 1 ? "" : "s"}!` : ""} Saved to your Space Log.`;
  record(true, r); speak("Hooray! You kept Mira and Leo safe!");
  for (let i = 0; i < 40; i++) { const c = document.createElement("span"); c.className = "conf"; c.textContent = pick(["🎉", "⭐", "✨", "🌟"]); c.style.left = Math.random() * 100 + "%"; c.style.animationDelay = Math.random() * 2 + "s"; document.body.appendChild(c); setTimeout(() => c.remove(), 5500); }
}
function gameOver() {
  locked = true; document.body.classList.remove("storm", "night"); show("end");
  $("eTitle").textContent = "Back to Earth!"; $("eEmoji").textContent = "🚀🌍";
  $("eStars").textContent = `💔 Out of hearts · ⭐ ${stars} stars`; $("stick").textContent = got.join(" ");
  $("eTxt").textContent = `Mira and Leo ran out of power on Moon day ${day} and flew home safely. Catch more ✨ next time! Saved to your Space Log.`;
  record(false, 0); speak("Mira and Leo had to fly back to Earth. Let's try again!");
}

// ---------- word challenges ----------
// [WORD, picture clue, fun fact]. Early days: fill the missing letter. Later days: unscramble the letters.
const WORDS = {
  food: [["CARROT", "🥕", "Carrots grow underground and are full of vitamins!"], ["POTATO", "🥔", "Potatoes grow underground and give lots of energy."], ["LETTUCE", "🥬", "Astronauts on the Space Station have grown and eaten lettuce!"], ["TOMATO", "🍅", "Astronauts have grown tomatoes on the Space Station!"], ["CORN", "🌽", "Corn plants need lots of sunshine to grow."], ["WHEAT", "🌾", "Wheat is ground into flour to make bread."], ["APPLE", "🍎", "Apples grow on trees and make a crunchy snack!"], ["BANANA", "🍌", "Bananas give quick energy for busy astronauts."]],
  water: [["WATER", "💧", "Your body is mostly made of water!"], ["ICE", "🧊", "Scientists have found ice in dark craters on the Moon!"], ["RAIN", "🌧️", "Rain falls from clouds and fills rivers and lakes on Earth."], ["CLOUD", "☁️", "Clouds are made of tiny drops of water."], ["OCEAN", "🌊", "Most of Earth's water is in the oceans."], ["SNOW", "❄️", "Snow is frozen water."], ["SHOWER", "🚿", "Astronauts in space use wet towels instead of showers!"]],
  air: [["WIND", "🌬️", "The Moon has almost no air, so it has no wind."], ["LEAF", "🍃", "Leaves make oxygen for us to breathe."], ["TREE", "🌳", "Trees give us oxygen and take in carbon dioxide."], ["PLANT", "🌿", "Plants use sunlight to make food and oxygen."], ["BUBBLE", "🫧", "A bubble is a thin skin of soap and water wrapped around air."], ["BALLOON", "🎈", "A balloon holds air inside."], ["KITE", "🪁", "Kites fly when wind pushes on them."], ["LUNGS", "🫁", "Your lungs take in oxygen from the air."]],
  energy: [["SUN", "☀️", "The Sun is a star. Its light gives us power!"], ["STAR", "⭐", "Stars like our Sun make their own light."], ["SPARK", "✨", "Solar panels turn sunlight into electricity."], ["POWER", "⚡", "Astronauts need power for lights, air and water machines."], ["LIGHT", "💡", "Moonlight is really sunlight bouncing off the Moon!"], ["BATTERY", "🔋", "A Moon night lasts about 14 Earth days, so batteries save power for the dark!"]]
};
const WORD_TITLE = { food: "Spell the food!", water: "Spell the water word!", air: "Spell the air word!", energy: "Bonus! Spell the power word ⭐ +1 🔋" };
function pickWord(kind, scramble) {
  const pool = WORDS[kind].filter(w => !scramble || w[0].length >= 4); let fresh = pool.filter(w => !used.has(w[0]));
  if (!fresh.length) { pool.forEach(w => used.delete(w[0])); fresh = pool; }
  const w = pick(fresh); used.add(w[0]); return w;
}
function wordChallenge(kind) {
  return new Promise(resolve => {
    const scramble = !tut && day > 2; // days 1-2 (and the tutorial): missing letter; days 3-5: unscramble
    let word, emoji, fact, mistakes, filled, done;
    const slots = $("wSlots"), tiles = $("wTiles"), msg = $("wMsg");
    const close = r => { $("word").classList.remove("on"); wordKey = null; resolve(r); };
    function load() {
      [word, emoji, fact] = pickWord(kind, scramble); mistakes = 0; filled = 0; done = false;
      $("wTitle").textContent = WORD_TITLE[kind]; $("wPic").textContent = emoji; msg.textContent = ""; msg.className = "wmsg";
      $("wOk").hidden = true; $("wNew").hidden = $("wBack").hidden = false; $("wBack").textContent = kind == "energy" ? "⏭ Skip" : "✖ Not now";
      $("wAsk").textContent = scramble ? "Tap the letters in the right order!" : "Which letter is missing?";
      if (scramble) {
        slots.innerHTML = [...word].map(() => `<span class="slot"></span>`).join("");
        let order; do order = shuffle([...word]); while (order.join("") == word);
        tiles.innerHTML = order.map(l => `<button class="tile" data-l="${l}">${l}</button>`).join("");
      } else {
        const bi = Math.floor(Math.random() * word.length), others = [..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"].filter(l => !word.includes(l));
        slots.innerHTML = [...word].map((l, i) => `<span class="slot ${i == bi ? "blank" : "fill"}" data-i="${i}">${i == bi ? "?" : l}</span>`).join("");
        tiles.innerHTML = shuffle([word[bi], ...shuffle(others).slice(0, 3)]).map(l => `<button class="tile" data-l="${l}">${l}</button>`).join("");
        slots.dataset.bi = bi;
      }
    }
    function win() {
      done = true; tiles.innerHTML = ""; $("wTitle").textContent = `🎉 ${word}!`; msg.textContent = fact; msg.className = "wmsg fact";
      $("wAsk").textContent = mistakes ? "You did it!" : "First try! Amazing!";
      $("wNew").hidden = $("wBack").hidden = true; $("wOk").hidden = false; $("wOk").focus(); beep(660, .1); setTimeout(() => beep(880, .15), 120); speak(`${word}. ${fact}`);
    }
    tiles.onclick = e => {
      const b = e.target.closest(".tile"); if (!b || done || b.disabled) return; const l = b.dataset.l;
      if (scramble) {
        if (l == word[filled]) { const sl = slots.children[filled++]; sl.textContent = l; sl.classList.add("fill"); b.disabled = true; beep(500 + filled * 60, .08); if (filled == word.length) win(); }
        else bad(b);
      } else {
        const bi = +slots.dataset.bi;
        if (l == word[bi]) { const sl = slots.children[bi]; sl.textContent = l; sl.classList.remove("blank"); sl.classList.add("fill", "ok"); win(); } else bad(b);
      }
    };
    function bad(b) { mistakes++; beep(200, .15, "square"); b.classList.add("shake"); setTimeout(() => b.classList.remove("shake"), 400); if (!scramble) b.disabled = true; msg.textContent = "Not that one. Try again!"; msg.className = "wmsg"; }
    $("wNew").onclick = load; $("wBack").onclick = () => close({ ok: false });
    $("wOk").onclick = () => close({ ok: true, perfect: mistakes == 0, word, fact });
    wordKey = ch => { const b = [...tiles.children].find(x => !x.disabled && x.dataset.l == ch); if (b) b.click(); };
    load(); $("word").classList.add("on");
  });
}
document.addEventListener("keydown", e => {
  if (!wordKey || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key == "Escape") $("wBack").click(); else if (/^[a-z]$/i.test(e.key)) wordKey(e.key.toUpperCase());
});

// ---------- wiring ----------
for (let i = 0; i < 70; i++) { const d = document.createElement("i"); d.style.left = Math.random() * 100 + "%"; d.style.top = Math.random() * 100 + "%"; d.style.animationDelay = Math.random() * 3 + "s"; $("sky").appendChild(d); }
$("play").onclick = () => { beep(660); if (!me) return openAuth(); ready = ready || loadNasa(); newGame(); };
ready = loadNasa(); // start fetching right away
$("voice").onclick = $("voiceT").onclick = toggleSound;
$("sunOk").onclick = sunOkClick;
$("bSun").onclick = catchGame; $("bFood").onclick = () => act("food"); $("bWater").onclick = () => act("water"); $("bAir").onclick = () => act("air");
$("bSleep").onclick = sleep; $("mira").onclick = () => hide("mira"); $("leo").onclick = () => hide("leo");
$("again").onclick = () => { ready = loadNasa(); newGame(); };
$("eHome").onclick = () => { refreshTitle(); show("title"); }; $("eLog").onclick = openLog;
$("logBtn").onclick = openLog; $("outBtn").onclick = signOut; $("lBack").onclick = () => { refreshTitle(); show("title"); };
$("lTut").onclick = () => { updatePlayer(p => p.tutorialDone = false); $("lTut").textContent = "✅ Tutorial will play next mission"; };
$("tabLogin").onclick = () => setTab("login"); $("tabSign").onclick = () => setTab("sign");
$("authBack").onclick = () => show("title");
$("fLogin").onsubmit = doLogIn; $("fSign").onsubmit = doSignUp;
$("chips").onclick = e => { const c = e.target.closest(".chip"); if (c) { $("liName").value = c.dataset.n; $("liPin").focus(); } };
$("avatars").onclick = e => { const a = e.target.closest(".av"); if (a) { pickedAvatar = a.dataset.a; renderAvatars(); } };
["liPin", "suPin", "suPin2"].forEach(i => $(i).oninput = () => { $(i).value = $(i).value.replace(/\D/g, "").slice(0, 4); });
try { const k = sessionStorage.getItem(SESSION_KEY); if (k && loadDB()[k]) me = k; } catch (e) {}
refreshTitle();
